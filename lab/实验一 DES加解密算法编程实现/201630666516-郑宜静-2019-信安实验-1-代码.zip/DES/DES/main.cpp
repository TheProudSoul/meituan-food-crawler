#include<iostream>
#include<fstream>
#include"DES.h"

using namespace std;

int _main() {

	// ��ָ���ļ��ж�ȡ����
	//ifstream readFile("src.txt");
	//char plaintext[65];
	//readFile >> plaintext;
	//readFile.close();
	//plaintext[64] = '\0';
	//
	//readFile.open("src2.txt");
	//char secretkey64[65];
	//readFile >> secretkey64;
	//readFile.close();
	//secretkey64[64] = '\0';
	//
	//DES des;
	//char* ciphertext = des.encrypt(plaintext,secretkey64);
	//cout << "ciphertext: " << ciphertext << endl;
	//
	//char* the_plaintext = des.decrypt(secretkey64, ciphertext);
	//cout << "the_plaintext: " << the_plaintext << endl;



	// ������д��ָ���ļ�
	//ofstream outputFile("target.txt");
	//outputFile << target;
	//outputFile.close();

	int output = 15;
	char tmp = 1;
	cout << ((tmp-'0')<< 1) << endl;
	cout << ((output & 0X08) >> 3) << ((output & 0X04) >> 2) << ((output & 0X02) >> 1) << (output & 0x01) << endl;;
	system("PAUSE");
	return 0;
}