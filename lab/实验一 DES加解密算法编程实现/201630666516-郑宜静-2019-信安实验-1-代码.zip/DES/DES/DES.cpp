#include<iostream>
#include"DES.h"

using namespace std;
char* DES::IP(char src[]) {

	char* target = new char[65];
	target[64] = '\0';
	for (size_t i = 0; i < 64; i += 4) {
		target[i] = src[IP_table[i] - 1];
		target[i + 1] = src[IP_table[i + 1] - 1];
		target[i + 2] = src[IP_table[i + 2] - 1];
		target[i + 3] = src[IP_table[i + 3] - 1];
	}

	return target;
}

char* DES::IP_reverse(char src[]) {
	char* target = new char[65];
	target[64] = '\0';

	for (size_t i = 0; i < 64; i += 4) {
		target[i] = src[IPreverse_table[i] - 1];
		target[i + 1] = src[IPreverse_table[i + 1] - 1];
		target[i + 2] = src[IPreverse_table[i + 2] - 1];
		target[i + 3] = src[IPreverse_table[i + 3] - 1];
	}
	return target;
}

char* DES::replace_choose_1(char src[]) {
	char* target = new char[57];
	target[56] = '\0';

	for (size_t i = 0; i < 56; i += 4) {
		target[i] = src[replace_choose_1_table[i] - 1];
		target[i + 1] = src[replace_choose_1_table[i + 1] - 1];
		target[i + 2] = src[replace_choose_1_table[i + 2] - 1];
		target[i + 3] = src[replace_choose_1_table[i + 3] - 1];
	}
	return target;
}

char* DES::reduce_64_to_56(char src[]) {
	char* target = new char[57];
	target[56] = '\0';
	for (size_t i = 0; i < 8; i++)
	{
		target[i * 7] = src[i * 8];
		target[i * 7 + 1] = src[i * 8 + 1];
		target[i * 7 + 2] = src[i * 8 + 2];
		target[i * 7 + 3] = src[i * 8 + 3];
		target[i * 7 + 4] = src[i * 8 + 4];
		target[i * 7 + 5] = src[i * 8 + 5];
		target[i * 7 + 6] = src[i * 8 + 6];
	}
	return target;
}

char* DES::get_right_half(char src[]) {
	char* target = new char[33];
	target[32] = '\0';
	for (size_t i = 0; i < 8; i++)
	{
		target[i * 4] = src[i * 8 + 4];
		target[i * 4 + 1] = src[i * 8 + 5];
		target[i * 4 + 2] = src[i * 8 + 6];
		target[i * 4 + 3] = src[i * 8 + 7];		
	}
	return target;
}

char* DES::get_left_half(char src[]) {
	char* target = new char[33];
	target[32] = '\0';
	for (size_t i = 0; i < 8; i++)
	{
		target[i * 4] = src[i * 8];
		target[i * 4 + 1] = src[i * 8 + 1];
		target[i * 4 + 2] = src[i * 8 + 2];
		target[i * 4 + 3] = src[i * 8 + 3];
	}
	return target;
}

char* DES::expend_32_to_48(char src[]) {
	char expend_table[8][2] = {
		{32,5},{4,9},{8,13},{12,17},{16,21},{20,25},{24,29},{28,1}
	};
	char* target = new char[49];
	target[48] = '\0';
	for (size_t i = 0; i < 8; i++)
	{
		target[i * 6] = expend_table[i][0];
		target[i * 6 + 5] = expend_table[i][1];
		target[i * 6 + 1] = src[i * 4];
		target[i * 6 + 2] = src[i * 4 + 1];
		target[i * 6 + 3] = src[i * 4 + 2];
		target[i * 6 + 4] = src[i * 4 + 3];
	}
	return target;
}

char* DES::left_shift(char src[], int iter) {
	int shift_bit = iteration_movement[iter];
	size_t i = 0;
	for ( ;i < 28-shift_bit; i++)
	{
		src[i] = src[i + shift_bit];
		src[i + 28] = src[i + 28 + shift_bit];
	}
	for (; i < 28; i++)
	{
		src[i] = src[i + 28] = 0;
	}
	return src;
}

char* DES::reduce_56_to_48(char src[]) {
	char* target = new char[49];
	target[48] = '\0';
	for (size_t i = 0; i < 48; i+=4)
	{
		target[i] = src[replace_choose_2_table[i] - 1];
		target[i + 1] = src[replace_choose_2_table[i + 1] - 1];
		target[i + 2] = src[replace_choose_2_table[i + 2] - 1];
		target[i + 3] = src[replace_choose_2_table[i + 3] - 1];
	}
	return target;
}

char* DES::XOR(char src1[], char src2[], int n) {
	char* target = new char[n+1];
	target[n] = '\0';
	for (size_t i = 0; i < n; i++)
	{
		if (src1[i] != src2[i])
			target[i] = '1';
		else target[i] = '0';
	}
	return target;
}

char* DES::S_box_replacement(char src[]) {
	const char* dictionary[16] = { "0000","0001","0010","0011","0100","0101","0110","0111","1000","1001","1010","1011","1100","1101","1110","1111" };
	char* target = new char[33];
	target[32] = '\0';
	for (size_t i = 0; i < 8; i++)
	{
		int row = (src[i * 6] - '0') * 2 + src[i * 6 + 5] - '0';
		int col = (src[i * 6 + 1] - '0') * 8 + (src[i * 6 + 2] - '0') * 4 + (src[i * 6 + 3] - '0') * 2 + src[i * 6 + 4] - '0';
		int output = S_boxs[i][row][col];
		target[i * 4] = dictionary[output][0];
		target[i * 4 + 1] = dictionary[output][1];
		target[i * 4 + 2] = dictionary[output][2];
		target[i * 4 + 3] = dictionary[output][3];
	}
	return target;
}

char* DES::replace_P(char src[]) {
	char* target = new char[33];
	target[32] = '\0';
	for (size_t i = 0; i < 32; i += 4) {
		target[i * 4] = src[replace_P_table[i * 4] - 1];
		target[i * 4 + 1] = src[replace_P_table[i * 4 + 1] - 1];
		target[i * 4 + 2] = src[replace_P_table[i * 4 + 2] - 1];
		target[i * 4 + 3] = src[replace_P_table[i * 4 + 3] - 1];
	}
	return target;
}

char* DES::encrypt(char plaintext[], char secretkey64[]) {
	cout << "plaintext: " << plaintext << endl;
	cout << "secretkey: " << secretkey64 << endl;
	char* plaintext_IP = IP(plaintext);
	char* secretkey56 = replace_choose_1(reduce_64_to_56(secretkey64));


	char* plaintext_L = get_left_half(plaintext_IP);
	char* plaintext_R = get_right_half(plaintext_IP);	

	for (int i = 0; i < 16; i++)
	{
		char* expended_plaintext = expend_32_to_48(plaintext_R);

		secretkey56 = left_shift(secretkey56, i);
		char* secretkey48 = reduce_56_to_48(secretkey56);

		char* the_xor = XOR(expended_plaintext, secretkey48, 48);

		char* S_replacement = S_box_replacement(the_xor);
		char* P_replacement = replace_P(S_replacement);
		if (i!=15)
		{
			char* temp = plaintext_R;
			plaintext_R = XOR(plaintext_L, P_replacement, 32);
		
			plaintext_L = temp;
		}
		
	}
	char* target = new char[65];
	target[64] = '\0';
	for (size_t i = 0; i < 8; i++)
	{
		target[i * 8] = plaintext_L[i * 4];
		target[i * 8 + 1] = plaintext_L[i * 4 + 1];
		target[i * 8 + 2] = plaintext_L[i * 4 + 2];
		target[i * 8 + 3] = plaintext_L[i * 4 + 3];
		target[i * 8 + 4] = plaintext_R[i * 4];
		target[i * 8 + 5] = plaintext_R[i * 4 + 1];
		target[i * 8 + 6] = plaintext_R[i * 4 + 2];
		target[i * 8 + 7] = plaintext_R[i * 4 + 3];
	}

	return IP_reverse(target);
}

char* DES::decrypt(char secretkey64[], char ciphertext[]) {
	cout << "ciphertext: " << ciphertext << endl;
	cout << "secretkey: " << secretkey64 << endl;
	char* ciphertext_IP = IP(ciphertext);
	char* secretkey56 = replace_choose_1(reduce_64_to_56(secretkey64));

	char* ciphertext_L = get_left_half(ciphertext_IP);
	char* ciphertext_R = get_right_half(ciphertext_IP);


	for (int i = 15; i >= 0; i--)
	{
		char* expended_plaintext = expend_32_to_48(ciphertext_R);

		secretkey56 = left_shift(secretkey56, i);
		char* secretkey48 = reduce_56_to_48(secretkey56);

		char* the_xor = XOR(expended_plaintext, secretkey48, 48);
		char* S_replacement = S_box_replacement(the_xor);
		char* P_replacement = replace_P(S_replacement);

		if (i!=0)
		{
			char* temp = ciphertext_R;
			ciphertext_R = XOR(ciphertext_L, P_replacement, 32);
			ciphertext_L = temp;
		}
		
	}
	char* target = new char[65];
	target[64] = '\0';
	for (size_t i = 0; i < 8; i++)
	{
		target[i * 8] = ciphertext_L[i * 4];
		target[i * 8 + 1] = ciphertext_L[i * 4 + 1];
		target[i * 8 + 2] = ciphertext_L[i * 4 + 2];
		target[i * 8 + 3] = ciphertext_L[i * 4 + 3];
		target[i * 8 + 4] = ciphertext_R[i * 4];
		target[i * 8 + 5] = ciphertext_R[i * 4 + 1];
		target[i * 8 + 6] = ciphertext_R[i * 4 + 2];
		target[i * 8 + 7] = ciphertext_R[i * 4 + 3];
	}

	return IP_reverse(target);
}